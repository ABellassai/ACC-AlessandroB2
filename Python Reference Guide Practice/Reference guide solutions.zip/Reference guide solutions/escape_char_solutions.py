#Use tab to tab space words on the screen
print("Tabbing \t\t across \t\t the \t\t\t  screen ")

#Use the newline \n to create a new line in a print statement
print("\nStart here then several new lines.. \n\n\n\n ...back again")

#Use a comment escape \' to quote some text in a print statement
print("I have no \'comment\' to make")

#Use a comment escape \" to quote some text in a print statement
print("I said I have no \"comment\" to make")