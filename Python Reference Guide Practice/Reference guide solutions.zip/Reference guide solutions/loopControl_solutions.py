# Write a loop to print the fruits in the list below. Use break to finish loop execution on banana
print("Exit the loop when we get a \"banana\": ")

fruits = ["apple", "banana", "cherry"]

for x in fruits:
  print(x)
  if x == "banana":
    break

# Use a loop to print the fruits in the list below. Use a continue to skip banana
print("\nDo not print banana: ")

fruits = ["apple", "banana", "cherry"]

for x in fruits:
  if x == "banana":
    continue
  print(x)


# Use a pass so that the loop below does nothing
print("\nif you for some reason have a for loop with no content, put in the pass statement \nto avoid getting an error.")
for x in [0, 1, 2]:
  pass