#Use a while loop to print the values from 1 to 5 

i = 1
while i < 6:
  print(i)
  i += 1


#use a for <variable> in <list> loop to print the fruits in the list below:

fruits = ["apple", "banana", "cherry"]

for x in fruits:
  print(x)
    
# Use a for <variable> in range(start,stop,step) loop to print all the values from 2 to 30 in steps of 3
#     <code>


for x in range(2, 30, 3):
  print(x)