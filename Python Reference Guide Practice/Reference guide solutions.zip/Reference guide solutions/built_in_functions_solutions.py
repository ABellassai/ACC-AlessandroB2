
# Use the sep argument in print(x, sep='y') to print "Hello --- how are you?"
print("Hello", "how are you?", sep="---")


# Use int to convert an age input into an int number
age = int(input("Please enter your age?: "))
print("Your age is: ",age)


# Use len(x) to find the length of the string and list below
myStr = "Hello"
myList = ["Apple","Orange"]
print("\nLength of String: ",len(myStr))
print("\nLength of List: ",len(myList))


#Use min() to print the minimum value in the list below
myList = [1,2,3,4,5,6,0,7,8,9,10]
print("\nMin value in list: ",min(myList))

#Use min() to print the maximum value in the list below
myList = [1,2,3,4,5,6,0,7,8,9,10]
print("\nMax value in list: ",max(myList))

#Use sum() to print the sum of the values in the list below
myList = [1,2,3,4,5,6,0,7,8,9,10]
print("\nSum values in list: ",sum(myList))


#Use range(n1,n2,n) returns a sequence of numbers from 3 to 20 in steps of 2
x = range(3, 20, 2)
print("\nRange 3 to 19 inclusive in Steps of 2: ")
for n in x:
  print(n)


#Use abs() to return the absolute value of num
num = -100.20
print("\nAbsolute value of ",num, " is ",abs(num))   ## TO DO


#Use round() to round num to 2 decimal places
num = 20.5245
print("\n20.5245 Rounded to 2 Decimal Places: ",round(num,2))


#Use type() to print the type of each of the following
myStr = "Hello"
decimal = 10.20
myList = [1,2,3,4,5]
print(type(myStr))
print(type(decimal))
print(type(myList))


#Use str(x) to convert PI to a string
pi = 3.14
##text = 'The value of pi is ' + pi      ## NO, does not work
text = "\nThe value of pi is "  + str(pi)  ## yes
print(text)


#Use list() to create a list from the string 'abcd'
my_string = 'abcd'
myList = list(my_string)

print("\nList: ",myList)


#Use int to converts my_str to an integer
my_str = 20
num = int(my_str)
print("\nString \"20\" to int: ",num)


#Use float to convert wholeNum to a float
wholeNum = 100
decimal = float(wholeNum)
print("\nInteger \"100\" to float: ",decimal)


#Use bool to convert a number to a Boolean value
x = bool(0)
print(x)

#Use pow to return 2 to the power of 4
result = pow(2,4) # 2 to the power of 4
print("\n2 to the power of 4: ",result)

#Use chr() to return the string value of the unicode code point 65
print("\nString value of unicode 65: ",chr(65))


#Use ord() to return the Unicode code of a single-character string - A
print("\nUnicode value of A: ",ord('A'))