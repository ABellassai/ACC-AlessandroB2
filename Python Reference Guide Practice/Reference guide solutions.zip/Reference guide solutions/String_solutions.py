
#Create a string with the words Hello World
my_str = "Hello World"

#Print the string
print(my_str)

# Use string.upper() to convert the string to uppercase
Upper_string = my_str.upper()

#print the string and the upper case string
print(my_str)
print(Upper_string)

# Use string.lower() to convert the string to lowercase
lower_string = my_str.lower()


#print the string and the lower case string
print(my_str)
print(lower_string)

# Use string.count() to count how many times the letter 'o' appers in the string. Store the value in a new variable and print it
num_o = my_str.count('o')
print(num_o)


# Use string.find() to get the index of the first occurrence of 'o'. Print this index
index_of_o = my_str.find('o')
print(index_of_o)

# use string.replace(x,y) to replay 'o' with 'a'. Print the new string
my_str_2 = my_str.replace('o','a')
print(my_str)
print(my_str_2)

#use string.islower() to test all characters are lowercase
print("All characters lower case? ",my_str.islower())

#use string.isupper() to test all characters are uppercase
print("All characters upper case? ",my_str.isupper())

#use string.isalnum() to test if all characters are alphanumeric
print("All alphanumeric: ",my_str.isalnum())

#use string.isalpha() to test if all characters are alphabetic
print("All alphabetic characters: ",my_str.isalpha())

#use string.isdigit() to test if all characters are digits
print("All Digti characters: ",my_str.isdigit())

#use string.index(s) to return the index of the substring 'll'
print("Return index of substring \"ll\": ",my_str.index("ll"))

# string.strip(x) to remove the leading and trailing characters in "     Hello world    "
my_str3 = "     Hello world    "
print("Return string with leading and trailing characters removed:",my_str3.strip())