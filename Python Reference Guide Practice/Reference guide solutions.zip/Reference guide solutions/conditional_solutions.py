
# if <condition> :
#     <code>
# elif <condition> :
#     <code>
# ...
# else:
#     <code>

#Use an if elif conditional check to find the greater, if either of a and b
a = 200
b = 33

if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")
else:
  print("a is greater than b")

#Use an if elif conditional check and boolean operators to find the largest, if any, of num1, num2, and num3
num1 = 10
num2 = 14
num3 = 12

if (num1 == num2) and (num1 == num3):
    print("All numbers are equal")
elif (num1 >= num2) and (num1 >= num3):
   largest = num1
   print("The largest number is", largest)
elif (num2 >= num1) and (num2 >= num3):
   largest = num2
   print("The largest number is", largest)
else:
   largest = num3
   print("The largest number is", largest)

#Use an if <value> in <list> conditional check to append a new list to the list each item that contains the letter 'a'


fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
newlist = []

for x in fruits:
  if "a" in x:
    newlist.append(x)

print(newlist)