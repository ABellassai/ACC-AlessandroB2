#Python Reference Guide Examples

#Start here and do what is requested in the comments
#Create a list that contains the following: "Apple", "Tomato", "Orange", "Cherry","Tomato
list = ["Apple", "Tomato", "Orange", "Cherry","Tomato"]

#print the list
print(list)

#use list.append() to append "Grape" to the end of the list
list.append("Grape")

#print the list
print(list)

#create a new list with "Blueberry" and "Blackberry"
list2 = ["Blueberry","Blackberry"]
#print the list
print(list2)

#use list.extend() to append the new list to the old list
list.extend(list2)
#print the updated list
print(list)
#use list.insert() to insert "Apple" at position 3
list.insert(3,"Apple")

#print the list
print(list)

#use list.remove() to remove the first item whose value is "Apple"
list.remove("Apple")

#print the list
print(list)


#use list.pop() to remove the item at position 2 from the list and return its value. Store its value in a variable
item_at_position_2 = list.pop(2)
#print the variable and the list
print(item_at_position_2)
print(list)

#use list.index() to return the position of the first occurrence of "Cherry" in the list. Store the position in a variable
index_of_1st_occur_cherry = list.index("Cherry")
#print the variable and the list
print(index_of_1st_occur_cherry)
print(list)
#use list.count() to count the number of times "Cherry" appears in the list and store it in a variable
num_cherry =list.count("Cherry")
#print the number of cherries and the list
print(num_cherry)
print(list)
#use list.sort() to sort the items in the list
list.sort()
#print the list
print(list)
#use sorted() to return a new list with the items  sorted. store the new list in a variable
new_list = sorted(list)
#print the list and the new list
print(list)
print(new_list)

#use list.reverse() to reverse the list elements
list.reverse()

#print the list
print(list)

#use list.copy() to store a copy of the list in a new variable
other_new_list = list.copy()

#print the list and the new copy
print(list)
print(other_new_list)


#use list.clear() to remove all the items in the list
list.clear()

#print the list
print(list)